#include "Figura.h"

void Figura::citire()
{
}
